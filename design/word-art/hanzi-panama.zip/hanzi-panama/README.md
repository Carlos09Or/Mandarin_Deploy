# Hanzi of Panama and Panama Oeste (units 1 and 2)

55 characters used by the 60 words of the first two provinces of the Mandarin journey app.

## Files

- `hanzi-list.csv` — one row per character:
  - `type`: **picture** (the old form looks like the thing), **idea** (two or more pictures combined),
    **meaning + sound** (one part gives the meaning, the other only gives the sound), **no clear history**.
  - `meaning_part` / `sound_part`: for meaning + sound characters. The sound part should NOT be illustrated as its meaning
    (in 妈 the 马 "horse" is only there for the sound "ma").
  - `decomposition`, `etymology_hint`: from Make Me a Hanzi (LGPL v3).
  - `our_parts`, `memory_line`: our own breakdown and mnemonic.
  - `used_in_words`: the words in the app that contain it.
- `reference/` — each modern character, centered on a 512 × 512 cream square, numbered like the CSV.
- `ancient-forms/` — the oldest forms we could get so far (oracle bone script), public domain, from Wikimedia Commons
  (Ancient Chinese characters project). Names are the Unicode code point: `5973-oracle.svg` is 女.
- `old-illustrations/` — the first attempt. They did not work: realistic figures do not match modern strokes.

## Goal

For each character, one simple flat illustration whose shape makes sense with the character, so the character
can appear on top of it. Picture characters follow their ancient form; idea characters combine the pictures of
their parts; for meaning + sound characters only the meaning part is pictured.
